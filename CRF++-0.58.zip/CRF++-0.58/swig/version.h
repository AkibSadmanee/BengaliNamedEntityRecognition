namespace CRFPP {
#define VERSION "0.58"
}
